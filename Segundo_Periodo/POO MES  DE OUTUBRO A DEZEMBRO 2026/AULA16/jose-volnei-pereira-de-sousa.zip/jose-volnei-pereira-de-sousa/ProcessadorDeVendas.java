
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Locale;

public class ProcessadorDeVendas {

    public static void main(String[] args) {

        try (
            BufferedReader leitor = new BufferedReader(
                new FileReader("vendas.txt")
            );

            BufferedWriter escritor = new BufferedWriter(
                new FileWriter("faturamento.txt")
            )
        ) {

            String linha;

        
            while ((linha = leitor.readLine()) != null) {

                try {

                    // Separa os dados usando a vírgula
                    String[] dados = linha.split(",", -1);

                    
                    if (dados.length < 3) {
                        throw new ArrayIndexOutOfBoundsException();
                    }

                    
                    if (dados.length > 3) {
                        System.out.println(
                            "Aviso: linha inválida '" +
                            linha + "' — linha ignorada."
                        );
                        continue;
                    }

                    
                    String produto = dados[0].trim();

                    
                    int quantidade = Integer.parseInt(dados[1].trim());
                    double preco = Double.parseDouble(dados[2].trim());

                    
                    double faturamento = quantidade * preco;

                    
                    String resultado = String.format(
                        Locale.US,
                        "%s: Faturamento R$%.2f",
                        produto,
                        faturamento
                    );

                    
                    escritor.write(resultado);
                    escritor.newLine();

                } catch (NumberFormatException e) {

                    System.out.println(
                        "Aviso: valor inválido na linha '" +
                        linha + "' — linha ignorada."
                    );

                } catch (ArrayIndexOutOfBoundsException e) {

                    System.out.println(
                        "Aviso: linha incompleta '" +
                        linha + "' — linha ignorada."
                    );
                }
            }

            System.out.println(
                "Processamento concluído. Resultados salvos em faturamento.txt."
            );

        } catch (FileNotFoundException e) {

            System.out.println(
                "Erro: o arquivo vendas.txt não foi encontrado."
            );

        } catch (IOException e) {

            System.out.println(
                "Erro: não foi possível ler ou escrever os arquivos."
            );
        }
    }
}
