import java.util.Scanner;

public class Questao3 {

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);

        int numero;

        do {
            System.out.print("Digite um número inteiro positivo: ");
            numero = ler.nextInt();
        } while (numero <= 0);

        int divisor = 2;
        boolean primo = true;

        while (divisor < numero) {

            if (numero % divisor == 0) {
                primo = false;
                break;
            }

            divisor++;
        }

        if (numero == 1) {
            primo = false;
        }

        if (primo) {
            System.out.println("O número é primo.");
        } else {
            System.out.println("O número não é primo.");
        }

        ler.close();
    }
}